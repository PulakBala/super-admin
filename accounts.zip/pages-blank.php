
<?php include('header.php') ?>
			<main class="content">
				<div class="container-fluid p-0">
					<!-- all  user  -->
					<div class="row">
						<div class="col-12 col-lg-8 col-xxl-9 d-flex">
							
						</div>
					
					</div>

				</div>
			</main>
<?php include('footer.php')?>



		